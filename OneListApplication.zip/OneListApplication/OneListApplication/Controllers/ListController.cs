﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OneListApplication.Controllers
{
    public class ListController : Controller
    {
        // GET: List

        public ActionResult CreateList()
        {
            return View();
        }

        public ActionResult EditList()
        {
            return View();
        }

        public ActionResult ShowListDetails()
        {
            return View();
        }

        public ActionResult ShowSubscribedList()
        {
            return View();
        }

        public ActionResult ShowCompleteList()
        {
            return View();
        }

    }
}